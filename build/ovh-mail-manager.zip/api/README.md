# OVH Mail Manager - Backend

To ensure the backend works properly, it's essential to configure your web server to point to its folder. You have
various options for local web servers, including WampServer, XAMPP, and more. Choose the one that best suits your needs
and configure and run it accordingly.[README.md](..%2F..%2FREADME.md)

Next, create the `config.php` file based on the `config-sample.php`. For more detailed information, refer to the
main documentation.